// Import express
const express = require('express');
const app = express();
const path = require('path');

// Middleware to parse form data
app.use(express.urlencoded({ extended: true }));

// Serve static files (like CSS or images later)
app.use(express.static(path.join(__dirname, 'public')));

// Route to display HTML form
app.get('/', (req, res) => {
  res.send(`
    <h2>User Form</h2>
    <form action="/submit" method="POST">
      <label>Name:</label>
      <input type="text" name="username" required><br><br>
      <label>Email:</label>
      <input type="email" name="email" required><br><br>
      <button type="submit">Submit</button>
    </form>
  `);
});

// Handle form submission
app.post('/submit', (req, res) => {
  const { username, email } = req.body;
  res.send(`<h2>Form Submitted!</h2><p>Name: ${username}</p><p>Email: ${email}</p>`);
});

// Start the server
app.listen(3000, () => {
  console.log('Server is running on http://localhost:3000');
});